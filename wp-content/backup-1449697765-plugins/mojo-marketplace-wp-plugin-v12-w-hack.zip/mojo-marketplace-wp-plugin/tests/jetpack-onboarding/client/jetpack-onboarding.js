var WelcomePanel = require('./welcome-panel');

WelcomePanel();