module.exports = {
	// steps
	SITE_TITLE_STEP_SLUG: 'title',
	LAYOUT_STEP_SLUG: 'layout',
	TRAFFIC_STEP_SLUG: 'traffic',
	STATS_MONITORING_STEP_SLUG: 'stats-monitoring',
	DESIGN_STEP_SLUG: 'design',
	ADVANCED_STEP_SLUG: 'advanced',
	JETPACK_MODULES_STEP_SLUG: 'jetpack',
	CONTACT_PAGE_STEP_SLUG: 'contact-page'
};