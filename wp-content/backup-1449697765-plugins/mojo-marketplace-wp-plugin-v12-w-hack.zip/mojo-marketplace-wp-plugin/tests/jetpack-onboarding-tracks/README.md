Jetpack Onboarding Stats Tracking
============================

# What is this?

"Tracks" tracking for JPO so that we can capture usage information.

# Who is it for?

Us, so we can see when people do the following things:

* start the wizard
* skip or complete a step
* hide the welcome panel