<?php
/**
 * The template part for displaying results in search pages.
 *
 * @package WordChef
 */
global $wordchef;

get_template_part( 'content', 'list' ); ?>